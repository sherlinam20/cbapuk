#!/usr/bin/env python3
import requests
import urllib.parse
import os
from bs4 import BeautifulSoup
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, IntPrompt

console = Console()

BASE_URL = "https://www.shodan.io/search/facet"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}

def build_query(dork_type, country, site):
    dorks = {
        "1": 'http.component:"laravel"',
        "2": 'http.html:"livewire.js"',
        "3": 'http.html:"wire:initial-data"',
        "4": 'http.title:"Laravel"',
        "5": 'http.favicon.hash:-1169115711'
    }
    q = [dorks.get(dork_type, dorks["1"])]
    if country: q.append(f'country:"{country.upper()}"')
    if site:
        site_fix = site.strip() if site.startswith(".") else f".{site.strip()}"
        q.append(f'hostname:"{site_fix}"')
    return " ".join(q)

def scrape_free(query, limit):
    encoded = urllib.parse.quote(query)
    url = f"{BASE_URL}?query={encoded}&facet=domain"
    
    with console.status("[bold yellow]Scraping via Facet (Free Mode)...[/bold yellow]", spinner="earth"):
        try:
            r = requests.get(url, headers=HEADERS, timeout=20)
            soup = BeautifulSoup(r.text, "html.parser")
            domains = []
            for a in soup.select("div.name a"):
                d = a.text.strip()
                if d and d not in domains:
                    domains.append(d)
                if len(domains) >= limit: break
            return domains
        except Exception as e:
            console.print(f"[red][!] Error Scrape: {e}[/red]")
            return []

def scrape_api(api_key, query, limit):
    with console.status("[bold green]Scraping Shodan via API (Gacor Mode)...[/bold green]", spinner="bouncingBall"):
        try:
            url = f"https://api.shodan.io/shodan/host/search?key={api_key}&query={query}&facets=domain"
            r = requests.get(url, timeout=25)
            data = r.json()
            
            if 'error' in data:
                console.print(f"[red][!] Shodan API Error: {data['error']}[/red]")
                return []
            
            domains = []
            for result in data.get('matches', []):
                domain = result.get('hostnames')
                if domain:
                    domains.append(domain[0])
                if len(domains) >= limit: break
            return list(set(domains))
        except Exception as e:
            console.print(f"[red][!] API Error: {e}[/red]")
            return []

def main():
    console.print(Panel.fit("[bold red]CVE Hunter v1.1 | Leu_Fangx7 [/bold red]\n[dim]Hybrid Shodan Engine (API & Scraper)[/dim]", border_style="red"))

    api_key = Prompt.ask("Masukkan Shodan API Key ([dim]Kosongkan jika mau mode Free[/dim])", default="")

    console.print("\n[1] ALL Component ( No Spesifik ) | [2] Component (spesifik) | [3] High | [4] Title | [5] Favicon")
    dork_choice = Prompt.ask("Pilih dork", choices=["1", "2", "3", "4", "5"], default="2")
    country = Prompt.ask("Country Code (ID, US, etc)", default="")
    site = Prompt.ask("Site/TLD filter (.com, .io)", default="")
    limit = IntPrompt.ask("Limit Domain", default=100)
    output = Prompt.ask("Output file", default="list.txt")

    query = build_query(dork_choice, country, site)
    
    if api_key:
        domains = scrape_api(api_key, query, limit)
    else:
        domains = scrape_free(query, limit)

    if domains:
        with open(output, "w") as f:
            for d in domains:
                f.write(f"https://{d}\n")
        
        console.print(Panel.fit(
            f"[bold green]SUCCESS[/bold green]\n"
            f"Dapet: [bold]{len(domains)}[/bold] domain\n"
            f"File: [bold cyan]{output}[/bold cyan]",
            border_style="green"
        ))
    else:
        console.print("[red][!] Gagal dapet domain. Coba ganti dork atau cek API Key lo.[/red]")
if __name__ == "__main__":
    main()
