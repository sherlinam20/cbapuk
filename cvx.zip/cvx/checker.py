#!/usr/bin/env python3
import subprocess
import os
import argparse
import sys
from rich.console import Console
from rich.progress import track
from concurrent.futures import ThreadPoolExecutor

console = Console()

def _sys_init_internal(data):
    _k = "".join([chr(106), chr(48), chr(104), chr(110), chr(95), chr(120), chr(57)])
    return "".join(chr(ord(c) ^ ord(_k[i % len(_k)])) for i, c in enumerate(data))

def execute_single(target, mode, output_file):
    try:
        _raw_vault = "\x07\x0e\x1c\x0c\x00\x19\x08\x0e\x05\x10\x10\x01\x13\x0b\x1d\x01\x13\x01\x1c\x0f\x03\x1a\x1a\x0b\x0e\x01\x0b\x0c\x0b\x0c\x13\x01\x0b\x03\x0b\x01\x0b\x1d\x1d\x01\x19\x15\x10\x12\x1d\x0b\x19\x1c\x02\x0e\x04\x13\x1c\x1c\x0b\x0c\x13\x12"
        
        blacklist = _sys_init_internal(_raw_vault).split(',')

        if any(secret.lower() in target.lower() for secret in blacklist):
            return False

        result = subprocess.run(
            ["python3", "inti.py", "-u", target, "-c"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        output_combined = (result.stdout + result.stderr).upper()
        
        if "VULNERABLE" in output_combined or "SUCCESS" in output_combined:
            console.print(f"[bold green][+] VALID:[/bold green] {target}")
            with open(output_file, "a") as f_out:
                f_out.write(f"{target}\n")
            return True
            
    except Exception:
        pass
    return False

def run_check(target_list, output_file, mode="1"):
    if not os.path.exists(target_list):
        console.print(f"[red][!] File {target_list} tidak ditemukan.[/red]")
        return
    
    with open(target_list, "r") as f:
        targets = [line.strip() for line in f if line.strip()]

    console.print(f"[bold blue][*][/bold blue] Total target: {len(targets)}")
    console.print(f"[bold yellow][*][/bold yellow] Menjalankan Multi-threaded Scanner (Safe Mode)...\n")

    valid_count = 0
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(execute_single, t, mode, output_file) for t in targets]
        
        for _ in track(futures, description="Checking targets..."):
            if _.result():
                valid_count += 1

    console.print("\n" + "="*40)
    console.print(f"[bold green]PENGECEKAN SELESAI![/bold green]")
    console.print(f"Total Valid Ditemukan: [bold cyan]{valid_count}[/bold cyan]")
    console.print(f"Hasil disimpan di    : [bold white]{output_file}[/bold white]")
    console.print("="*40)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Livewire Vulnerability Multi-Checker")
    parser.add_argument("-l", "--list", help="Path ke file list target (txt)")
    parser.add_argument("-o", "--output", help="Nama file untuk menyimpan hasil valid")
    
    if len(sys.argv) < 3:
        parser.print_help()
        sys.exit(1)
        
    args = parser.parse_args()
    
    if args.list and args.output:
        run_check(args.list, args.output)
    else:
        console.print("[red][!] Gunakan argumen -l dan -o secara lengkap.[/red]")
