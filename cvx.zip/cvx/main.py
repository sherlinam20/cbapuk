#!/usr/bin/env python3
import os
import sys
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

console = Console()

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def main():
    clear()
    console.print(Panel.fit(
        "[bold cyan]CVE NEW HUNTER v1.1[/bold cyan]\n"
        "[white]Logic: Leu_FangX7 | Private tools [/white]", 
        border_style="blue"
    ))

    console.print("[1] Auto Dorking \n[2] Check Vulnerability\n[3] Auto Upshell\n[4] Full Automatic")
    task = Prompt.ask("Pilih Menu", choices=["1", "2", "3", "4"])

    if task == "1":
        os.system("python3 autodork.py")

    elif task == "2":
        list_file = Prompt.ask("Masukkan path list", default="list.txt")
        out_file = Prompt.ask("Output valid", default="valid.txt")
        os.system(f"python3 checker.py -l {list_file} -o {out_file}")

    elif task == "3":
        list_file = Prompt.ask("Masukkan path list (Hasil Check)", default="valid.txt")
        out_file = Prompt.ask("Output Shell", default="shells.txt")
        os.system(f"python3 upshell.py -l {list_file} -o {out_file}")

    elif task == "4":
        console.print("[yellow][!] Menjalankan Full Auto Mode...[/yellow]")
        os.system("python3 autodork.py")
        os.system("python3 checker.py -l list.txt -o valid.txt")
        os.system("python3 upshell.py -l valid.txt -o shells.txt")

if __name__ == "__main__":
    main()
